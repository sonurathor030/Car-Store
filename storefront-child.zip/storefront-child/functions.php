<?php
// Enqueue parent theme styles
function storefront_child_enqueue_styles() {
    wp_enqueue_style( 'storefront-parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/assets/css/style.css', [], '1.0.0', 'all' );
    wp_enqueue_script( 'child-script', get_stylesheet_directory_uri() .'/assets/js/main.js', array('jquery'), time() );
	wp_localize_script( 'child-script', 'car_entry', [
		'ajax_url' => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'car_entry_nonce' )
	]);
}
add_action( 'wp_enqueue_scripts', 'storefront_child_enqueue_styles' );

// Add custom functions or hooks here
require_once get_stylesheet_directory() . '/inc/car-add-cpt.php';
require_once get_stylesheet_directory() . '/inc/shortcode-car-entry.php';
require_once get_stylesheet_directory() . '/inc/shortcode-car-list.php';
require_once get_stylesheet_directory() . '/inc/admin-submenu-car.php';
