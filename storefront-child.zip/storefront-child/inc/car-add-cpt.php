<?php
if ( ! class_exists( 'Car_Post_Type' ) ) {
    class Car_Post_Type {

        public function __construct() {
            add_action( 'init', [ $this, 'register_car_post_type' ] );
            add_action( 'init', [ $this, 'register_taxonomies' ] );
        }

        public function register_car_post_type() {
            $labels = [
                'name'               => __( 'Cars', 'storefront-child'),
                'singular_name'      => __( 'Car', 'storefront-child'),
                'menu_name'          => __( 'Cars', 'storefront-child'),
                'add_new'            => __( 'Add New Car', 'storefront-child'),
                'add_new_item'       => __( 'Add New Car', 'storefront-child'),
                'edit_item'          => __( 'Edit Car', 'storefront-child'),
                'new_item'           => __( 'New Car', 'storefront-child'),
                'view_item'          => __( 'View Car', 'storefront-child'),
                'search_items'       => __( 'Search Cars', 'storefront-child'),
                'not_found'          => __( 'No cars found', 'storefront-child'),
                'not_found_in_trash' => __( 'No cars found in Trash', 'storefront-child'),
            ];

            $args = [
                'labels'              => $labels,
                'public'              => true,
                'has_archive'         => true,
                'show_in_rest'        => true,
                'supports'            => [ 'title', 'thumbnail', 'editor' ],
                'menu_icon'           => 'dashicons-car',
                'show_ui'             => true,
                'capability_type'     => 'post',
            ];

            register_post_type( 'car', $args );
        }

        public function register_taxonomies() {
            $taxonomies = [
                'make' => __( 'Make', 'storefront-child'),
                'model' => __( 'Model', 'storefront-child'),
                'year' => __( 'Year', 'storefront-child'),
                'fuel_type' => __( 'Fuel Type', 'storefront-child'),
            ];

            foreach ( $taxonomies as $taxonomy => $label ) {
                $args = [
                    'labels' => [
                        'name'              => $label,
                        'singular_name'     => $label,
                        'search_items'      => __( 'Search ' . $label, 'storefront-child'),
                        'all_items'         => __( 'All ' . $label, 'storefront-child'),
                        'edit_item'         => __( 'Edit ' . $label, 'storefront-child'),
                        'add_new_item'      => __( 'Add New ' . $label, 'storefront-child'),
                    ],
                    'public' => true,
                    'hierarchical' => true,
                    'show_ui' => true,
                    'show_in_rest' => true,
                    'show_admin_column' => true,
                ];
                register_taxonomy( $taxonomy, 'car', $args );
            }
        }
    }

    new Car_Post_Type();
}
