<?php
// File: shortcode-car-list.php
if ( ! class_exists( 'Car_List_Shortcode' ) ) {
    class Car_List_Shortcode {
        public function __construct() {
            add_shortcode( 'car-list', [ $this, 'display_car_list' ] );
        }

        public function display_car_list() {
            $args = [
                'post_type' => 'car',
                'posts_per_page' => -1
            ];
            $cars = new WP_Query( $args );
            ob_start();

            if ( $cars->have_posts() ) {
                ?>
                <table class="car-list-table">
                    <thead>
                        <tr>
                            <th><?php _e( 'Car Name', 'storefront-child' ); ?></th>
                            <th><?php _e( 'Make', 'storefront-child' ); ?></th>
                            <th><?php _e( 'Model', 'storefront-child' ); ?></th>
                            <th><?php _e( 'Year', 'storefront-child' ); ?></th>
                            <th><?php _e( 'Fuel Type', 'storefront-child' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ( $cars->have_posts() ) {
                            $cars->the_post();
                            $post_id = get_the_ID();
                            ?>
                            <tr>
                                <td><?php the_title(); ?></td>
                                <td><?php echo get_the_term_list( $post_id, 'make', '', ', ' ); ?></td>
                                <td><?php echo get_the_term_list( $post_id, 'model', '', ', ' ); ?></td>
                                <td><?php echo get_the_term_list( $post_id, 'year', '', ', ' ); ?></td>
                                <td><?php echo get_the_term_list( $post_id, 'fuel_type', '', ', ' ); ?></td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                wp_reset_postdata();
            } else {
                _e( 'No cars found.', 'storefront-child' );
            }

            return ob_get_clean();
        }
    }

    new Car_List_Shortcode();
}
