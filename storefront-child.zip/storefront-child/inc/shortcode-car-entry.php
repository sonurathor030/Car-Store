<?php
if ( ! class_exists( 'Car_Entry_Shortcode' ) ) {
    class Car_Entry_Shortcode {

        public function __construct() {
            add_shortcode( 'car_entry', [ $this, 'car_entry_form' ] );
            add_action( 'wp_ajax_add_car_entry', [ $this, 'handle_car_entry' ] );
            add_action( 'wp_ajax_nopriv_add_car_entry', [ $this, 'handle_car_entry' ] );
        }

        public function car_entry_form() {
            ob_start(); ?>

            <form id="car-entry-form" method="post" enctype="multipart/form-data">
                <label for="car_name"><?php _e( 'Car Name', 'storefront-child' ); ?></label>
                <input type="text" id="car_name" name="car_name" required><br><br>

                <label for="make"><?php _e( 'Make', 'storefront-child' ); ?></label>
                <select id="make" name="make">
                    <?php $makes = get_terms( [ 'taxonomy' => 'make', 'hide_empty' => false ] );
                    foreach ( $makes as $make ) {
                        echo "<option value='{$make->term_id}'>{$make->name}</option>";
                    } ?>
                </select><br><br>

                <label for="model"><?php _e( 'Model', 'storefront-child' ); ?></label>
                <select id="model" name="model">
                    <?php $models = get_terms( [ 'taxonomy' => 'model', 'hide_empty' => false ] );
                    foreach ( $models as $model ) {
                        echo "<option value='{$model->term_id}'>{$model->name}</option>";
                    } ?>
                </select><br><br>
                <label for="year"><?php _e( 'Year', 'storefront-child' ); ?></label>
                <select id="year" name="year">
                    <?php 
                    $years = get_terms([ 'taxonomy' => 'year', 'hide_empty' => false ]);
                    foreach ( $years as $year ) {
                        echo "<option value='{$year->term_id}'>{$year->name}</option>";
                    } ?>
                </select><br><br>
                <label><?php _e( 'Fuel Type', 'storefront-child' ); ?></label>
                <?php $fuel_types = get_terms( [ 'taxonomy' => 'fuel_type', 'hide_empty' => false ] );
                foreach ( $fuel_types as $fuel_type ) {
                    echo "<input type='radio' name='fuel_type' value='{$fuel_type->term_id}' required>{$fuel_type->name}<br>";
                } ?><br><br>

                <label for="car_image"><?php _e( 'Car Image', 'storefront-child' ); ?></label>
                <input type="file" id="car_image" name="car_image"><br><br>

                <input type="submit" value="<?php _e( 'Submit', 'storefront-child' ); ?>">
            </form>

            <div id="response"></div>

            <?php return ob_get_clean();
        }

        public function handle_car_entry() {
            check_ajax_referer( 'car_entry_nonce', 'nonce' );

            $car_name  = sanitize_text_field( $_POST['car_name'] );
            $make      = intval( $_POST['make'] );
            $model     = intval( $_POST['model'] );
            $year      = intval( $_POST['year'] );
            $fuel_type = intval( $_POST['fuel_type'] );

            $post_id = wp_insert_post( [
                'post_title'  => $car_name,
                'post_type'   => 'car',
                'post_status' => 'publish',
            ] );

            if ( ! is_wp_error( $post_id ) ) {
                wp_set_object_terms( $post_id, [ $make ], 'make' );
                wp_set_object_terms( $post_id, [ $model ], 'model' );
                wp_set_object_terms( $post_id, [ $year ], 'year' );
                wp_set_object_terms( $post_id, [ $fuel_type ], 'fuel_type' );

                if ( ! empty( $_FILES['car_image']['name'] ) ) {
                    $attachment_id = media_handle_upload( 'car_image', $post_id );
                    if ( ! is_wp_error( $attachment_id ) ) {
                        set_post_thumbnail( $post_id, $attachment_id );
                    }
                }

                wp_send_json_success( __( 'Car added successfully!', 'storefront-child' ) );
            } else {
                wp_send_json_error( __( 'Error adding car.', 'storefront-child' ) );
            }

            wp_die();
        }
    }

    new Car_Entry_Shortcode();
}