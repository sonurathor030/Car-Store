<?php
// File: admin-submenu-car.php

if ( ! class_exists( 'Car_Shortcode_Submenu' ) ) {
    class Car_Shortcode_Submenu {

        public function __construct() {
            add_action( 'admin_menu', [ $this, 'add_shortcode_submenu' ] );
        }

        public function add_shortcode_submenu() {
            add_submenu_page(
                'edit.php?post_type=car',   // Parent slug (CPT "Car")
                __( 'Car Shortcodes', 'storefront-child' ), // Page title
                __( 'Shortcodes', 'storefront-child' ), // Menu title
                'manage_options',            // Capability
                'car-shortcodes',            // Menu slug
                [ $this, 'render_shortcode_page' ] // Callback function to display content
            );
        }

        public function render_shortcode_page() {
            ?>
            <div class="wrap">
                <h1><?php _e( 'Car Shortcodes', 'storefront-child' ); ?></h1>
                
                <h2><?php _e( 'Available Shortcodes:', 'storefront-child' ); ?></h2>
                
                <h3>[car_entry]</h3>
                <p><?php _e( 'This shortcode displays a form to enter a new car. The submitted car will be saved as a "Car" custom post type.', 'storefront-child' ); ?></p>
                
                <h3>[car-list]</h3>
                <p><?php _e( 'This shortcode displays a list of all cars added in the system.', 'storefront-child' ); ?></p>
            </div>
            <?php
        }
    }

    new Car_Shortcode_Submenu();
}
