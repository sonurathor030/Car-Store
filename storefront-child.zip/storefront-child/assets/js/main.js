// File: js/car-entry.js
jQuery(document).ready(function ($) {
    $('#car-entry-form').on('submit', function (e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        formData.append('action', 'add_car_entry');
        formData.append('nonce', car_entry.nonce);
        
        $.ajax({
            url: car_entry.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.success) {
                    $('#response').html('<p>' + response.data + '</p>');
                    $('#car-entry-form')[0].reset();
                } else {
                    $('#response').html('<p>' + response.data + '</p>');
                }
            },
            error: function () {
                $('#response').html('<p>Error submitting the form.</p>');
            }
        });
    });
});
